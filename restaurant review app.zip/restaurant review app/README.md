# Restaurant Reviews App Project

This is my project in the fourthpart

## Steps to follow:
1. Open the terminal in your project folder and run using `python -m SimpleHTTPServer 8000` 
2. Run index.html using browser.
3. View all the restaurants.
4. View the details of the restaurant by selecting the place you required and the type of cuisine you like.
5. You can also review your thought about the restaurant in the review section.  


